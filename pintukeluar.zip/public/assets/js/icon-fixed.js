$(document).ready(function (){
    $('.whatsapp-list, .whatsapp-close').hide();
    $('.whatsapp-ready').click(function() {
        $('.whatsapp-list, .whatsapp-close').show();
        $('.whatsapp-ready').hide();
    });
    $('.whatsapp-close').click(function() {
        $('.whatsapp-list, .whatsapp-close').hide();
        $('.whatsapp-ready').show();
    });
});