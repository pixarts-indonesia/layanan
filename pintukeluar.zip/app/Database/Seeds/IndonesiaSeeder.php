<?php

namespace App\Database\Seeds;

class IndonesiaSeeder extends \CodeIgniter\Database\Seeder
{
    private $time;

    public function run()
    {
        helper('date');
        $this->time = date('Y-m-d H:i:s', now());
        $this->db->table('language')->insertBatch($this->data());
    }

    public function data(): array
    {
        return [
            // Input
            [
                'code_language' => 'id',
                'index' => 'name',
                'text' => 'Nama',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'email',
                'text' => 'Email',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'message',
                'text' => 'Pesan',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],

            // Buttons
            [
                'code_language' => 'id',
                'index' => 'language',
                'text' => 'Bahasa',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'home',
                'text' => 'Beranda',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'product',
                'text' => 'Produk',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'blog',
                'text' => 'Blog',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'about',
                'text' => 'Tentang',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'contact',
                'text' => 'Hubungi Kami',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'sand',
                'text' => 'Kirim',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'more',
                'text' => 'Selengkapnya',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],

            // Information
            [
                'code_language' => 'id',
                'index' => 'title',
                'text' => 'PintuKeluar.',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'title_contact',
                'text' => 'Punya Masalah',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'sub_contact',
                'text' => 'Jika ada masalah atau pertanyaan bisa langsung isi data dibawah ini.',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'title_slider',
                'text' => 'Hadir untuk Indonesia',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'sub_slider',
                'text' => 'Pintu merupakan sarana untuk membatasi ruang lingkup, kemampuan dan hal-hal lainnya sehingga akan sangat terbatas ruang geraknya. Pintu juga menjadi sarana jalur membedakan antar ruang, pintu merupaka jalan untuk masuk dan keluar dari satu sisi ke sisi lainnya. <br>Kami <span class="text-success">pintukeluar.id</span>',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'social_media',
                'text' => 'Media Sosial',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'menu',
                'text' => 'Menu',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'all_rights_reserved',
                'text' => 'Seluruh hak cipta.',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'title_about',
                'text' => 'Tentang',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'list',
                'text' => 'Daftar',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'service',
                'text' => 'Layanan',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'fitur_detail',
                'text' => 'Fitur Detail',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'maps',
                'text' => 'Peta',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'contact_us',
                'text' => 'Hubungi Kami',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'id',
                'index' => 'contact_us_sub',
                'text' => 'Hubungi kami tentang produk mitra usaha/mitra patner',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
        ];
    }
}
