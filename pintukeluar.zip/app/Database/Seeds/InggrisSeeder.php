<?php

namespace App\Database\Seeds;

class InggrisSeeder extends \CodeIgniter\Database\Seeder
{
    private $time;

    public function run()
    {
        helper('date');
        $this->time = date('Y-m-d H:i:s', now());
        $this->db->table('language')->insertBatch($this->data());
    }

    public function data(): array
    {
        return [
            // Input
            [
                'code_language' => 'en',
                'index' => 'name',
                'text' => 'Nama',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'email',
                'text' => 'Email',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'message',
                'text' => 'Message',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],

            // Buttons
            [
                'code_language' => 'en',
                'index' => 'language',
                'text' => 'Language',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'home',
                'text' => 'Home',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'product',
                'text' => 'Product',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'blog',
                'text' => 'Blog',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'about',
                'text' => 'About',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'contact',
                'text' => 'Contact Us',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'sand',
                'text' => 'Sand',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'more',
                'text' => 'More',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],

            // Information
            [
                'code_language' => 'en',
                'index' => 'title',
                'text' => 'PintuKeluar.',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'title_contact',
                'text' => 'Got A Problem',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'sub_contact',
                'text' => 'If there are problems or questions, please fill in the data below.',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'title_slider',
                'text' => 'Coming to Indonesia',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'sub_slider',
                'text' => 'The door is a means to limit the scope, capabilities and other things so that the space for movement will be very limited. The door is also a means of passage to distinguish between spaces, the door is a way to enter and exit from one side to the other. <br>We <span class="text-success">pintukeluar.id</span>',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'social_media',
                'text' => 'Social Media',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'menu',
                'text' => 'Menu',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'all_rights_reserved',
                'text' => 'All rights reserved.',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'title_about',
                'text' => 'About',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'list',
                'text' => 'List',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'service',
                'text' => 'Service',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'fitur_detail',
                'text' => 'Detailed Features',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'maps',
                'text' => 'Maps',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'contact_us',
                'text' => 'Contact Us',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
            [
                'code_language' => 'en',
                'index' => 'contact_us_sub',
                'text' => 'Contact us about business partner/partner products',
                'created_at' => $this->time,
                'updated_at' => $this->time,
            ],
        ];
    }
}
