<?= $this->extend('App\Views\Layout\main') ?>

<?= $this->section('slider') ?>
    <section id="home" class="home">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="main-banner">
						<div class="d-sm-flex justify-content-between">
							<div data-aos="zoom-in-up">
								<div class="banner-title">
									<h3 class="font-weight-medium"><?= @$lang->title_slider; ?></h3>
								</div>
								<p class="mt-3 pl-0 col-sm-12 col-lg-9"><?= @$lang->sub_slider; ?></p>
								<a href="<?= base_url('/about'); ?>" class="btn btn-secondary mt-3"><?= @$lang->more; ?></a>
							</div>
							<div class="mt-5 mt-lg-0">
								<img src="<?= base_url('assets/images/group.png'); ?>" alt="pintukeluar" class="img-fluid" data-aos="zoom-in-up">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="our-services" id="services">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h5 class="text-dark"><?= @$lang->list; ?></h5>
					<h3 class="font-weight-medium text-dark mb-5"><?= @$lang->service; ?></h3>
				</div>
			</div>
			<div class="row" data-aos="fade-up">
				<div class="col-sm-4 text-center text-lg-left">
					<div class="services-box" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1500">
						<img src="<?= base_url('assets/icon/sun.gif'); ?>" alt="integrated-marketing" data-aos="zoom-in" class="icon-list-product">
						<h6 class="text-dark mb-3 mt-4 font-weight-medium">Integrated 
							Marketing
						</h6>
						<p>Lorem ipsum dolor sit amet, 
							pretium pretium tempor.Lorem ipsum 
						</p>
					</div>
				</div>
				<div class="col-sm-4 text-center text-lg-left">
					<div class="services-box" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1500">
						<img src="<?= base_url('assets/icon/partly-cloudy-day.gif'); ?>" alt="integrated-marketing" data-aos="zoom-in" class="icon-list-product">
						<h6 class="text-dark mb-3 mt-4 font-weight-medium">Design & 
							Development
						</h6>
						<p>Lorem ipsum dolor sit amet, 
							pretium pretium tempor.Lorem ipsum 
						</p>
					</div>
				</div>
				<div class="col-sm-4 text-center text-lg-left">
					<div class="services-box" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1500">
						<img src="<?= base_url('assets/icon/cloud-lightning.gif'); ?>" alt="integrated-marketing" data-aos="zoom-in" class="icon-list-product">
						<h6 class="text-dark mb-3 mt-4 font-weight-medium">Digital 
							Strategy
						</h6>
						<p>Lorem ipsum dolor sit amet, 
							pretium pretium tempor.Lorem ipsum 
						</p>
					</div>
				</div>
			</div>
			<div class="row" data-aos="fade-up">
				<div class="col-sm-4 text-center text-lg-left">
					<div class="services-box  pb-lg-0" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1500">
						<img src="<?= base_url('assets/icon/rain-cloud.gif'); ?>" alt="digital-marketing" data-aos="zoom-in" class="icon-list-product">
						<h6 class="text-dark mb-3 mt-4 font-weight-medium">Digital 
							Marketing
						</h6>
						<p>Lorem ipsum dolor sit amet, 
							pretium pretium tempor.Lorem ipsum 
						</p>
					</div>
				</div>
				<div class="col-sm-4 text-center text-lg-left">
					<div class="services-box pb-lg-0" data-aos="fade-down" data-aos-easing="linear" data-aos-duration="1500">
						<img src="<?= base_url('assets/icon/umbrella.gif'); ?>" alt="digital-marketing" data-aos="zoom-in" class="icon-list-product">
						<h6 class="text-dark mb-3 mt-4 font-weight-medium">Growth 
							Strategy
						</h6>
						<p>Lorem ipsum dolor sit amet, 
							pretium pretium tempor.Lorem ipsum 
						</p>
					</div>
				</div>
			</div>
		</div>
	</section>

<?= $this->endSection() ?>
<?= $this->section('content') ?>

<?= $this->endSection() ?>