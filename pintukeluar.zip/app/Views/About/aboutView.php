<?= $this->extend('App\Views\Layout\main') ?>

<?= $this->section('content') ?>
<div class="container">
        <div class="row">
            <div class="col-sm-6" data-aos="fade-up">
                <h3 class="font-weight-medium text-dark"><?= @$lang->about ?></h3>
                <p>Sebuah Perjalanan dan dedikasi dengan orang-orang yang di belakang layar.</p>
                <div class="d-flex justify-content-start mb-3">
                    <ul class="fa-ul">
                        <li>
                            <h6 class="mb-0">2022</h6>
                            <p>
                                Misi membantu menyelesaikan masalah dan kesulitan yang dihadapi dalam perjalanan dari satu titik ke titik lainnya.
                                <br> Dari 1 misi yang baik untuk masyarakat Indonesia.
                                <br> Website menjadi awal untuk memberikan informasi dalam menghadapi permasalahan selama perjalanan jalur darat.
                            </p>
                        </li>
                        <li>
                            <h6 class="mb-0">2022</h6>
                            <p>
                                Misi membantu menyelesaikan masalah dan kesulitan yang dihadapi dalam perjalanan dari satu titik ke titik lainnya.
                                <br> Dari 1 misi yang baik untuk masyarakat Indonesia.
                                <br> Website menjadi awal untuk memberikan informasi dalam menghadapi permasalahan selama perjalanan jalur darat.
                            </p>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6 text-right" data-aos="flip-left" data-aos-easing="ease-out-cubic" data-aos-duration="2000">
                <img src="<?= base_url('/assets/images/idea.png'); ?>" alt="idea" class="img-fluid">
            </div>
        </div>
    </div>
<?= $this->endSection() ?>