<?php
use Config\Services;
$request = Services::request();
$uri = $request->uri->getSegment(1);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
		<!-- Required meta tags --> 
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title>Pintu Keluar</title>
		<link rel="stylesheet" href="<?= base_url('assets/vendors/mdi/css/materialdesignicons.min.css'); ?>">
		<link rel="stylesheet" href="<?= base_url('assets/vendors/owl.carousel/css/owl.carousel.css'); ?>">
		<link rel="stylesheet" href="<?= base_url('assets/vendors/owl.carousel/css/owl.theme.default.min.css'); ?>">
		<link rel="stylesheet" href="<?= base_url('assets/vendors/aos/css/aos.css'); ?>">
		<link rel="stylesheet" href="<?= base_url('assets/vendors/jquery-flipster/css/jquery.flipster.css'); ?>">
		<link rel="stylesheet" href="<?= base_url('assets/css/style.css'); ?>">
		<link rel="shortcut icon" href="<?php base_url('assets/images/favicon.png'); ?>" />
    </head>
    <!-- body -->
	<body data-spy="scroll" data-target=".navbar" data-offset="50">
		<div id="mobile-menu-overlay"></div>
		<nav class="navbar navbar-expand-lg fixed-top">
			<div class="container">
				<a class="navbar-brand" href="<?= base_url('/'); ?>"><?= @$lang->title; ?></a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon">
						<i class="mdi mdi-menu"></i>
					</span>
				</button>
				<div class="collapse navbar-collapse" id="navbarTogglerDemo01">
					<div class="d-lg-none d-flex justify-content-between px-4 py-3 align-items-center">
						<img src="<?= base_url('assets/images/logo-dark.svg'); ?>" class="logo-mobile-menu" alt="logo">
						<a href="javascript:;" class="close-menu"><i class="mdi mdi-close"></i></a>
					</div>
					<ul class="navbar-nav ml-auto align-items-center">
						<li class="nav-item">
							<a class="nav-link <?= ($uri == null) ? 'active' : '' ?>" href="<?= base_url('/'); ?>"><?= @$lang->home; ?></a>
						</li>
						<li class="nav-item">
							<a class="nav-link <?= ($uri == 'product') ? 'active' : '' ?>" href="<?= base_url('product'); ?>"><?= @$lang->product; ?></a>
						</li>
						<li class="nav-item">
							<a class="nav-link <?= ($uri == 'about') ? 'active' : '' ?>" href="<?= base_url('about'); ?>"><?= @$lang->about; ?></a>
						</li>
						<li class="nav-item">
							<a class="nav-link <?= ($uri == 'contact') ? 'active' : '' ?>" href="<?= base_url('contact'); ?>"><?= @$lang->contact; ?></a>
						</li>
                        <div class="dropdown cursor-pointer">
                            <span class="nav-link btn btn-success dropdown-toggle" data-toggle="dropdown">
							<?= @$lang->language; ?>
                            </span>
                            <ul class="dropdown-menu p-3 rounded">
								<?php foreach (@$master_language as $key => $value) : ?>
									<li class="py-3 px-1">
										<a class="text-decoration-none" href="<?= base_url('lang/'.@$value->code_language); ?>">
											<span class="font-weight-bold text-dark">
												<?= strtoupper(@$value->code_language); ?>
											</span>
										</a>
									</li>
									<hr class="p-0 m-0">
								<?php endforeach; ?>
                            </ul>
                        </div>
					</ul>
				</div>
			</div>
		</nav>
		<div class="page-body-wrapper">
            <?= $this->renderSection('slider') ?>
			<section class="contactus">
				<div class="container">
					<div class="row mb-5 py-5">
                        <?= $this->renderSection('content') ?>
					</div>
				</div>
			</section>
		</div>
		<footer class="footer">
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-sm-6">
							<h6 class="footer-title"><?= @$lang->contact_us; ?></h6>
							<p class="mb-2">
								<span><?= @$lang->contact_us_sub; ?></span>
							</p>
							<div class="d-flex align-items-center mb-2">
								<b class="pr-2">Email :</b><a href="mailto:stephan@pintukeluar.id" class="footer-link mr-4 mb-0">stephan@pintukeluar.id</a>
							</div>
							<div class="d-flex align-items-center">
								<b class="pr-2">Email :</b><a href="mailto:hrd@pintukeluar.id" class="footer-link mr-4 mb-0">hrd@pintukeluar.id</a>
							</div>
							<div class="social-icons">
								<h6 class="footer-title font-weight-bold">
									<?= @$lang->social_media; ?>
								</h6>
								<div class="mb-3">
									<a href="https://www.tiktok.com/@pintukeluar.id" class="mr-3 text-center" target="_blank" rel="noopener noreferrer">
										<img src="<?= base_url('assets/icon/tiktok.gif'); ?>" alt="tiktok" class="icon-size rounded bg-white mb-2">
									</a>
									<a href="https://www.facebook.com/profile.php?id=100087929764176" class="mr-3 text-center" target="_blank" rel="noopener noreferrer">
										<img src="<?= base_url('assets/icon/facebook.gif'); ?>" alt="facebook" class="icon-size rounded bg-white mb-2">
									</a>
									<a href="https://www.youtube.com/channel/UCxseEbS26x3dKxNDnhQGPTg" class="mr-3 text-center" target="_blank" rel="noopener noreferrer">
										<img src="<?= base_url('assets/icon/youtube.gif'); ?>" alt="youtube" class="icon-size rounded bg-white mb-2">
									</a>
									<a href="https://www.instagram.com/pintukeluar.id/" class="mr-3 text-center" target="_blank" rel="noopener noreferrer">
										<img src="<?= base_url('assets/icon/instagram.gif'); ?>" alt="instagram" class="icon-size rounded bg-white mb-2">
									</a>
									<a href="https://twitter.com/PintuKeluarId" class="mr-3 text-center" target="_blank" rel="noopener noreferrer">
										<img src="<?= base_url('assets/icon/twitter.gif'); ?>" alt="twitter" class="icon-size rounded bg-white mb-2">
									</a>
								</div>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="row">
								<div class="col-sm-5">
									<h6 class="footer-title"><?= @$lang->fitur_detail; ?></h6>
									<ul class="list-footer">
										<li><a href="<?= base_url('/'); ?>" class="footer-link"><?= @$lang->home; ?></a></li>
										<li><a href="<?= base_url('product'); ?>" class="footer-link"><?= @$lang->product; ?></a></li>
										<li><a href="<?= base_url('blog'); ?>" class="footer-link"><?= @$lang->blog; ?></a></li>
										<li><a href="<?= base_url('about'); ?>" class="footer-link"><?= @$lang->about; ?></a></li>
										<li><a href="<?= base_url('contact'); ?>" class="footer-link"><?= @$lang->contact; ?></a></li>
									</ul>
								</div>
								<div class="col-sm-4">
									<address>
										<h6 class="footer-title"><?= @$lang->maps; ?></h6>
										<ul class="list-footer">
											<div class="mapouter"><div class="gmap_canvas"><iframe width="300" height="300" id="gmap_canvas" src="https://maps.google.com/maps?q=yogyakarta&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://123movies-to.org">123movies</a><br><style>.mapouter{position:relative;text-align:right;height:300px;width:300px;}</style><a href="https://www.embedgooglemap.net">google map html widget</a><style>.gmap_canvas {overflow:hidden;background:none!important;height:300px;width:300px;}</style></div></div>
										</ul>
									</address>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="footer-bottom">
				<div class="container">
					<div class="d-flex justify-content-between align-items-center">
						<div class="d-flex align-items-center">
							<a href="<?= base_url('/'); ?>" class="text-white text-decoration-none">
								<h3><?= @$lang->title; ?></h3>
								<p class="mb-0 text-small pt-1"> © <?= date('Y') ?>. <?= @$lang->all_rights_reserved; ?></p>
							</a>
						</div>
					</div>
				</div>
			</div>
		</footer>
		
		<div class="social-icons">
			<div class="social-position">
				<p class="pt-2 whatsapp-list bg-white shadow pt-3 pb-2 px-2 rounded">
					<a href="#">
						<img src="<?= base_url('assets/icon/whatsapp.gif'); ?>" alt="youtube" class="icon-size rounded bg-white mb-2">
					</a>
				</p>
				<p class="pt-2 whatsapp-list bg-white shadow pt-3 pb-2 px-2 rounded">
					<a href="#">
						<img src="<?= base_url('assets/icon/whatsapp.gif'); ?>" alt="youtube" class="icon-size rounded bg-white mb-2">
					</a>
				</p>
				<p class="cursor-pointer whatsapp-ready bg-white shadow pt-2 px-2 rounded">
					<img src="<?= base_url('assets/icon/whatsapp.gif'); ?>" alt="youtube" class="icon-size rounded bg-white mb-2">
				</p>
				<p class="pt-2 whatsapp-close cursor-pointer bg-white shadow pt-3 pb-2 px-2 rounded">
					<img src="<?= base_url('assets/icon/cancel.gif'); ?>" alt="youtube" class="icon-size rounded bg-white mb-2">
				</p>
			</div>
		</div>
		<script src="<?= base_url('assets/vendors/base/vendor.bundle.base.js') ?>"></script>
		<script src="<?= base_url('assets/vendors/owl.carousel/js/owl.carousel.js') ?>"></script>
		<script src="<?= base_url('assets/vendors/aos/js/aos.js') ?>"></script>
		<script src="<?= base_url('assets/vendors/jquery-flipster/js/jquery.flipster.min.js') ?>"></script>
		<script src="<?= base_url('assets/js/icon-fixed.js') ?>"></script>
		<script src="<?= base_url('assets/js/template.js') ?>"></script>		
	</body>
</html>