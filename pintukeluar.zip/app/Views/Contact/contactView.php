<?= $this->extend('App\Views\Layout\main') ?>

<?= $this->section('content') ?>
<div class="col-sm-5" data-aos="fade-up" data-aos-offset="-500">
        <img src="<?= base_url('assets/images/contact.jpg'); ?>" alt="contact" class="img-fluid">
    </div>
    <div class="col-sm-7" data-aos="fade-up" data-aos-offset="-500">
        <h3 class="font-weight-medium text-dark mt-5 mt-lg-0"><?= @$lang->title_contact; ?></h3>
        <h5 class="text-dark mb-5"><?= @$lang->sub_contact; ?></h5>
        <form>
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <input type="text" class="form-control" id="name" placeholder="<?= @$lang->name; ?> *">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group">
                        <input type="email" class="form-control" id="mail" placeholder="<?= @$lang->email; ?> *">
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="form-group">
                        <textarea name="message" id="message" class="form-control" placeholder="<?= @$lang->message; ?> *" rows="5"></textarea>
                    </div>
                </div>
                <div class="col-sm-12">
                    <a href="#" class="btn btn-secondary"><?= strtoupper(@$lang->sand); ?></a>
                </div>
            </div>
        </form>
    </div>
<?= $this->endSection() ?>