<?= $this->extend('App\Views\Layout\main') ?>

<?= $this->section('content') ?>

<?= $this->endSection() ?>